# SkillCoach AI SaaS Platform

SkillCoach is an AI‑powered coaching platform designed to help users improve their soft skills and interview performance.  
The platform provides feedback using Azure Cognitive Services and GPT‑4o through Microsoft Azure OpenAI.  
It includes two main subprojects: a **FastAPI** backend and a **Next.js** frontend.

## Project structure

This repository contains two top‑level directories:

- **backend/** – Contains the FastAPI server used to orchestrate calls to Azure services.
- **frontend/** – Contains the React/Next.js frontend application.

## Running the project locally

Prerequisites:

- Python 3.9 or newer
- Node.js (version 16 or newer)
- An Azure subscription with the following services enabled:
  - Azure Speech service
  - Azure Face API
  - Azure OpenAI (GPT‑4o deployment)

To run both parts of the project, follow the setup instructions in the `backend/README.md` and `frontend/README.md` files.