# Frontend – Next.js

This directory contains the React/Next.js frontend for SkillCoach.

## Setup

1. Install dependencies:

   ```bash
   npm install
   ```

2. Create a `.env.local` file in this directory and define the URL of your backend API:

   ```
   NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
   ```

   Adjust the host and port if your backend server is running elsewhere.

## Running the development server

Start the frontend development server:

```bash
npm run dev
```

The app will be available at `http://localhost:3000` by default.

## Build and production

To build the app for production, run:

```bash
npm run build
npm start
```

This will compile the application and serve it in production mode.