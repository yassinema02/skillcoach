"""
FastAPI application exposing endpoints to interact with Azure Cognitive Services.

Endpoints:
- `/transcribe`  – Transcribe audio to text via Azure Speech service.
- `/analyze-face` – Detect faces and extract facial attributes via Azure Face API.
- `/analyze-text` – Analyze text via Azure OpenAI (GPT‑4o).

You must configure Azure credentials in a `.env` file placed in the `backend/` directory. See
`backend/README.md` for details.
"""

import os
import tempfile
from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
import requests
import openai
from dotenv import load_dotenv

try:
    # Azure Speech SDK is optional: if not installed, speech transcription won't work.
    from azure.cognitiveservices.speech import SpeechConfig, AudioConfig, SpeechRecognizer
except ImportError:
    SpeechConfig = None  # type: ignore
    AudioConfig = None  # type: ignore
    SpeechRecognizer = None  # type: ignore

# Load environment variables from `.env` file, if present
load_dotenv()

app = FastAPI(title="SkillCoach Backend API", version="0.1.0")

# Azure environment variables
SPEECH_KEY = os.getenv("AZURE_SPEECH_KEY")
SPEECH_REGION = os.getenv("AZURE_SPEECH_REGION")

FACE_KEY = os.getenv("AZURE_FACE_KEY")
FACE_ENDPOINT = os.getenv("AZURE_FACE_ENDPOINT")

OPENAI_KEY = os.getenv("AZURE_OPENAI_KEY")
OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")

# Configure OpenAI client for Azure OpenAI if keys are provided
if OPENAI_KEY and OPENAI_ENDPOINT:
    openai.api_type = "azure"
    openai.api_key = OPENAI_KEY
    openai.api_base = OPENAI_ENDPOINT
    # The API version may need to be updated when new models are released.
    openai.api_version = "2024-05-01-preview"


class TextRequest(BaseModel):
    """Schema for text analysis requests."""
    text: str


@app.post("/transcribe")
async def transcribe_audio(file: UploadFile = File(...)):
    """Transcribe an uploaded audio file using Azure Speech‑to‑Text.

    The client must send a multipart/form‑data request with a single audio file. The
    speech service will be invoked to perform the transcription. Only basic error
    handling is implemented here; for production use you may want to support
    additional languages or streaming recognition.
    """
    if not SPEECH_KEY or not SPEECH_REGION:
        raise HTTPException(status_code=500, detail="Speech service keys are not configured.")
    if SpeechConfig is None:
        raise HTTPException(status_code=500, detail="Azure Speech SDK is not installed.")
    try:
        contents = await file.read()
        # Write the uploaded audio to a temporary file. The Speech SDK currently
        # only accepts files from disk for synchronous recognition.
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
            temp_audio.write(contents)
            temp_audio_path = temp_audio.name
        speech_config = SpeechConfig(subscription=SPEECH_KEY, region=SPEECH_REGION)
        audio_input = AudioConfig(filename=temp_audio_path)
        recognizer = SpeechRecognizer(speech_config=speech_config, audio_config=audio_input)
        result = recognizer.recognize_once()
        # Remove the temporary file to free resources
        os.remove(temp_audio_path)
        if hasattr(result, "reason") and result.reason == result.Reason.RecognizedSpeech:
            return {"transcript": result.text}
        else:
            raise HTTPException(status_code=400, detail=f"Speech recognition failed: {getattr(result, 'reason', 'Unknown error')}")
    except Exception as exc:
        # Wrap generic exceptions in HTTPException for FastAPI
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/analyze-face")
async def analyze_face(file: UploadFile = File(...)):
    """Analyze facial expressions from an uploaded image using Azure Face API."""
    if not FACE_KEY or not FACE_ENDPOINT:
        raise HTTPException(status_code=500, detail="Face API keys are not configured.")
    try:
        contents = await file.read()
        url = f"{FACE_ENDPOINT.rstrip('/')}/face/v1.0/detect"
        params = {
            "returnFaceAttributes": "age,gender,emotion",
            # You could also request `returnFaceId`, `detectionModel`, etc.
        }
        headers = {
            "Ocp-Apim-Subscription-Key": FACE_KEY,
            "Content-Type": "application/octet-stream",
        }
        response = requests.post(url, params=params, headers=headers, data=contents, timeout=10)
        if response.status_code != 200:
            # Propagate error details from Azure API
            raise HTTPException(status_code=response.status_code, detail=response.text)
        faces = response.json()
        return {"faces": faces}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/analyze-text")
async def analyze_text(request: TextRequest):
    """Analyze user‑supplied text using Azure OpenAI (GPT‑4o).

    The request body must contain a `text` field. The endpoint returns a
    single message with the analysis from the GPT model. For production use
    you may want to add more control over temperature, max_tokens and system
    prompting.
    """
    if not OPENAI_KEY or not OPENAI_ENDPOINT or not OPENAI_DEPLOYMENT:
        raise HTTPException(status_code=500, detail="OpenAI service keys are not configured.")
    message = request.text.strip()
    if not message:
        raise HTTPException(status_code=400, detail="Input text cannot be empty.")
    try:
        result = openai.ChatCompletion.create(
            deployment_id=OPENAI_DEPLOYMENT,
            messages=[
                {"role": "system", "content": "You are a helpful assistant for soft skills coaching."},
                {"role": "user", "content": message},
            ],
            max_tokens=256,
            temperature=0.7,
        )
        return {"analysis": result.choices[0].message.content.strip()}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))