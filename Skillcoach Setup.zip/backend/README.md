# Backend – FastAPI

This directory contains the FastAPI server for SkillCoach.  
It exposes endpoints that proxy requests to Azure services for speech‑to‑text, facial expression analysis and natural‑language analysis via GPT‑4o.

## Setup

1. Create a Python virtual environment and activate it:

   ```bash
   python -m venv venv
   source venv/bin/activate
   ```

2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Create a `.env` file in this directory and populate it with your Azure credentials.  
   The keys below correspond to the respective Azure Cognitive Services resources:

   ```
   AZURE_SPEECH_KEY=your_speech_key
   AZURE_SPEECH_REGION=your_speech_region

   AZURE_FACE_KEY=your_face_key
   AZURE_FACE_ENDPOINT=https://your-face-endpoint.cognitiveservices.azure.com/

   AZURE_OPENAI_KEY=your_openai_key
   AZURE_OPENAI_ENDPOINT=https://your-openai-endpoint.openai.azure.com/
   AZURE_OPENAI_DEPLOYMENT=your-gpt4o-deployment-name
   ```

## Running the server

Run the FastAPI server with Uvicorn:

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

This will start the API server on `http://localhost:8000` by default.  
You can then access the OpenAPI schema at `http://localhost:8000/docs`.

## Available endpoints

- **POST `/transcribe`** – Accepts an audio file (multipart/form‑data) and returns a transcript using Azure Speech‑to‑Text.
- **POST `/analyze-face`** – Accepts an image file (multipart/form‑data) and returns facial expression analysis using the Azure Face API.
- **POST `/analyze-text`** – Accepts a JSON body with a `text` field and returns analysis via Azure OpenAI (GPT‑4o).

Refer to `app/main.py` for implementation details.