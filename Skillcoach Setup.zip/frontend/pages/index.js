import { useState } from 'react';
import axios from 'axios';

export default function Home() {
  const [text, setText] = useState('');
  const [textAnalysis, setTextAnalysis] = useState('');
  const [transcript, setTranscript] = useState('');
  const [faces, setFaces] = useState(null);
  const [loading, setLoading] = useState(false);

  // Base URL for the backend API. See `.env.local`.
  const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8000';

  const handleTextSubmit = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setLoading(true);
    try {
      const response = await axios.post(`${apiBaseUrl}/analyze-text`, { text });
      setTextAnalysis(response.data.analysis);
    } catch (err) {
      alert(err.response?.data?.detail || err.message);
    }
    setLoading(false);
  };

  const handleAudioChange = async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);
    try {
      const response = await axios.post(`${apiBaseUrl}/transcribe`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setTranscript(response.data.transcript);
    } catch (err) {
      alert(err.response?.data?.detail || err.message);
    }
    setLoading(false);
  };

  const handleImageChange = async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);
    try {
      const response = await axios.post(`${apiBaseUrl}/analyze-face`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setFaces(response.data.faces);
    } catch (err) {
      alert(err.response?.data?.detail || err.message);
    }
    setLoading(false);
  };

  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif', maxWidth: '800px', margin: 'auto' }}>
      <h1>SkillCoach</h1>
      <p>Interact with the backend to transcribe audio, analyze text and detect facial expressions.</p>

      <section style={{ marginTop: '2rem' }}>
        <h2>Analyze Text</h2>
        <form onSubmit={handleTextSubmit} style={{ marginBottom: '1rem' }}>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={4}
            cols={60}
            placeholder="Enter text for analysis..."
            style={{ width: '100%', padding: '0.5rem' }}
          />
          <br />
          <button type="submit" disabled={loading || !text.trim()} style={{ marginTop: '0.5rem' }}>
            Analyze
          </button>
        </form>
        {textAnalysis && (
          <div>
            <h3>Analysis:</h3>
            <p>{textAnalysis}</p>
          </div>
        )}
      </section>

      <section style={{ marginTop: '2rem' }}>
        <h2>Transcribe Audio</h2>
        <input type="file" accept="audio/*" onChange={handleAudioChange} disabled={loading} />
        {transcript && (
          <div>
            <h3>Transcript:</h3>
            <p>{transcript}</p>
          </div>
        )}
      </section>

      <section style={{ marginTop: '2rem' }}>
        <h2>Analyze Facial Expressions</h2>
        <input type="file" accept="image/*" onChange={handleImageChange} disabled={loading} />
        {faces && (
          <div>
            <h3>Faces detected:</h3>
            <pre style={{ background: '#f7f7f7', padding: '1rem', overflowX: 'auto' }}>{JSON.stringify(faces, null, 2)}</pre>
          </div>
        )}
      </section>
    </main>
  );
}